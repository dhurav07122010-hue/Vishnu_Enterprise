import { QueryClient } from "@tanstack/react-query";
import { supabase } from "./client";

// Initialize Supabase auth on the client: restore session and listen for changes.
export function initSupabaseAuth(queryClient: QueryClient) {
  if (typeof window === "undefined") return () => {};

  // Try to restore session immediately
  (async () => {
    try {
      const { data } = await supabase.auth.getSession();
      const user = data.session?.user ?? null;
      // Seed the react-query cache so UI can read `currentUser` instantly
      queryClient.setQueryData(["currentUser"], user ?? undefined);
    } catch (e) {
      console.error("Error restoring Supabase session:", e);
    }
  })();

  // Subscribe to auth changes and keep the query cache in sync
  const { data: sub } = supabase.auth.onAuthStateChange((event, session) => {
    try {
      const user = session?.user ?? null;
      if (user) {
        queryClient.setQueryData(["currentUser"], user);
      } else {
        queryClient.setQueryData(["currentUser"], undefined);
      }
    } catch (err) {
      console.error("Error handling auth state change:", err);
    }
  });

  return () => {
    sub?.subscription?.unsubscribe?.();
    // older versions of supabase client expose `unsubscribe` on the returned object
    try {
      // @ts-ignore
      sub?.unsubscribe?.();
    } catch {}
  };
}

export default initSupabaseAuth;
